import { useState, useEffect } from "react";
import PacmanLoader from "react-spinners/PacmanLoader";
import axios from "axios";

const apiKey = "68fcf8ca6de6cd66d21c17e2ca9537bc";
const properties = {
  display: "block",
  margin: "50px auto",
};

export default function Forecast({ lat, lon }) {
  const [stage, setStage] = useState(false);
  const [response, setResponse] = useState(null);

  let apiURL = `https://api.openweathermap.org/data/2.5/onecall?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

  function renderUrl() {
    axios.get(apiURL).then(function (resp) {
      setResponse(resp.data);
    });
  }

  if (!stage) {
    renderUrl();
    setStage(true);
    return (
      <PacmanLoader
        color="#d9d9ee"
        loading={true}
        cssOverride={properties}
        size={50}
      />
    );
  }

  if (response != null) {
    let responseMas = response.daily;

    function round(value) {
      return Math.round(value);
    }

    let days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];

    return (
      <div className="row">
        {responseMas.map(function (daily, index) {
          if (index < 6 && index > 0) {
            let apiDate = new Date(response.daily.dt * 1000);

            let datatime = {
              day: apiDate.getDay(),
              date: apiDate.getDate(),
              month: apiDate.getMonth() + 1,
            };

            //console.log(response.daily);
            return (
              <div className="col card me-1 py-3" key={index}>
                <h5 className="card-title">
                  {days[datatime.day]},{" "}
                  {datatime.date < 10 ? `0${datatime.date}` : datatime.date}.
                  {datatime.month < 10 ? `0${datatime.month}` : datatime.month}
                </h5>
                <img
                  src="http://openweathermap.org/img/wn/01d@2x.png"
                  alt="img"
                />
                <p className="card-text small-temperature">
                  Max: {round(daily.temp.max)}°C <br />
                  <span className="text-muted">
                    Min: {round(daily.temp.min)}°C
                  </span>
                </p>
              </div>
            );
          }
        })}
      </div>
    );
  }
}
